#StudentName :Nisarg Sojitra
#Studentid   :20CS088
#Aim         :learn Set,Dictionary,Tuple
#link(Github): 

#following program for Tuple

#Que1:Write a python program to create tuple with diffrent data types
fruit_tuple=('mango','apple','chikoo',10,True)
print(fruit_tuple)                   #print tuple as it's

#Que2:Write a python program to create tuple with numbers and print one item
num_tuple=(12,24,45,590)
print(num_tuple[0])                  #print item at index 0

#Que3:Write a python program to add item in tupple
example_tuple=('A','B','C','D')
example_tuple=example_tuple+('E',)   #add item in below tuple and print final tuple
print(example_tuple)

#Que4:Write a python program to convert tuple to string
con_tuple=('j','a','c','k')         
N1="".join(con_tuple)                #use join() function to convert tuple to string
print(N1)

#Que5:Write a python program to find length of tuple
N_tuple=('i','n','d','i','a')
print(len(N_tuple))                  #use len function to find length of tuple
